HTML5 Audio Visualizer
======================

An audio spectrum visualizer built with HTML5 Audio API

Demo
---
[See it in action](http://wayou.github.io/HTML5_Audio_Visualizer/).

Screen Capture
---

![alt tag](https://raw.github.com/Wayou/HTML5_Audio_Visualizer/master/sources/screencapture.png)
