3D Audio Spectrum VIsualizer
============================

a 3d audio spectrum viauslizer built with three.js


[See it in action](http://wayou.github.io/3D_Audio_Spectrum_VIsualizer/).

Screen Capture

![alt tag](https://raw.github.com/Wayou/3D_Audio_Spectrum_VIsualizer/master/sources/screenshot.jpg)
